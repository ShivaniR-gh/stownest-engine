import type { DatasetDef, Row } from '../../src/config/types';
import type { Principal } from '../../src/lib/permissions/policy';
import { HttpError } from './env';
import { readDataset } from './sheets';
import { getDatasetDef } from './registry';

/** ---------------------------------------------------------------------------
 * Server-side field derivation.
 *
 * Some columns are written by the server rather than the user: figures computed
 * from what was entered, facts copied from a master record, audit stamps. They
 * live here rather than in the form because a value the browser calculates is a
 * value the browser can lie about.
 *
 * Derivation runs AFTER validation and AFTER the permission check.
 * ------------------------------------------------------------------------- */

export type Deriver = (
  values: Row,
  ctx: { principal: Principal; tab: string },
) => Promise<Row>;

const DERIVERS: Record<string, Deriver> = {

  /**
   * A space reading stores only wh_code and occupied_space from the user.
   * Everything else is derived:
   *
   *  - wh_name / city / location / total_space are SNAPSHOT from the warehouse
   *    master at write time. Snapshotting rather than joining is deliberate:
   *    when a warehouse is expanded from 11,247 to 15,000 sqft in June, March's
   *    reading must keep showing 11,247. A live join would silently rewrite
   *    every past month's utilisation and reshape the trend chart.
   *
   *  - available_space and utilisation_pct are computed, never entered. The
   *    source sheet has rows where these disagree with the figures above them.
   */
  warehouse_readings: async (values, { principal }) => {
    const code = String(values.wh_code ?? '').trim();
    if (!code) throw new HttpError(400, 'A warehouse must be selected.');

    const master = await getDatasetDef('warehouses');
    const { rows } = await readDataset(master);
    const wh = rows.find(r => String(r.wh_code ?? '').trim() === code);

    if (!wh) {
      throw new HttpError(400,
        `Warehouse "${code}" is not in the warehouse list. Ask an admin to add it first.`);
    }
    if (String(wh.status ?? 'Active').trim().toLowerCase() === 'inactive') {
      throw new HttpError(400, `Warehouse "${code}" is marked inactive and cannot take new readings.`);
    }

    const total = Number(String(wh.total_space ?? '').replace(/[,\s]/g, ''));
    const occupied = Number(String(values.occupied_space ?? '').replace(/[,\s]/g, ''));

    if (Number.isNaN(total) || total <= 0) {
      throw new HttpError(400, `Warehouse "${code}" has no valid total space recorded.`);
    }
    if (occupied > total) {
      throw new HttpError(400,
        `Occupied space (${occupied.toLocaleString('en-IN')}) cannot exceed this warehouse's total space of ${total.toLocaleString('en-IN')} sqft.`);
    }

    return {
      ...values,
      wh_name:        String(wh.wh_name ?? ''),
      city:           String(wh.city ?? ''),
      location:       String(wh.location ?? ''),
      total_space:    String(total),
      occupied_space: String(occupied),
      available_space: String(total - occupied),
      utilisation_pct: total > 0 ? (occupied / total * 100).toFixed(1) : '0',
      recorded_on:    String(values.recorded_on ?? new Date().toISOString().slice(0, 10)),
      entered_by:     principal.email,
    };
  },

  /**
   * The employee enters what they are looking at on the statement: what was
   * raised and what came in. The gap between the two is arithmetic, so the
   * server does it — a figure a person retypes is a figure that can disagree
   * with the two numbers above it, and the sheet already has months where it
   * does.
   *
   * Share in revenue is NOT derived. The historical sheet's share figures do
   * not reconcile against any denominator in the data, so computing one here
   * would silently replace the team's definition with a guess.
   */
  collections_monthly: async (values) => {
    const raised = num(values.raised_amount);
    const collected = num(values.collection_month);

    if (collected > raised) {
      throw new HttpError(400,
        `Collected (${raised.toLocaleString('en-IN')}) cannot exceed the amount raised.`);
    }

    const pending = raised - collected;
    return {
      ...values,
      pending_amount: String(pending),
      gap_pct: raised > 0 ? ((pending / raised) * 100).toFixed(2) : '0',
    };
  },

  collections_segments: async (values) => {
    const raised = num(values.raised_amount);
    const collected = num(values.collection_amount);

    if (collected > raised) {
      throw new HttpError(400, 'Collected cannot exceed the amount raised for this segment.');
    }

    const gap = raised - collected;
    return {
      ...values,
      gap_amount: String(gap),
      gap_pct: raised > 0 ? ((gap / raised) * 100).toFixed(2) : '0',
    };
  },
};

/** Sheet figures arrive with commas and stray spaces. */
const num = (v: unknown): number => {
  const n = Number(String(v ?? '').replace(/[,\s₹]/g, ''));
  return Number.isFinite(n) ? n : 0;
};

export async function derive(
  ds: DatasetDef,
  values: Row,
  ctx: { principal: Principal; tab: string },
): Promise<Row> {
  const fn = DERIVERS[ds.id];
  return fn ? fn(values, ctx) : values;
}