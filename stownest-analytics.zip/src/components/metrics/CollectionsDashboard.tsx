import { useMemo, useState } from 'react';
import '@/styles/collections.css';
import type { Row } from '@/config/types';
import { ChartFrame } from '@/components/charts/ChartFrame';
import { TrendChart } from '@/components/charts/TrendChart';
import { CategoryChart } from '@/components/charts/CategoryChart';
import { SectionHeader } from '@/components/metrics/MetricCard';
import { Button, EmptyState } from '@/components/primitives';
import { CollectionsEntryForm } from './CollectionsEntryForm';
import { formatINRCompact, formatInt, formatPct, parseDate, toNum } from '@/lib/format';

/** ---------------------------------------------------------------------------
 * Collections dashboard.
 *
 * Deliberately NOT the capacity dashboard: there is no capacity/occupied pair
 * here, so utilisation bands would be meaningless. This reads two datasets —
 * one row per month, and one row per month per revenue segment — and shows the
 * selected month's figures with the surrounding months as context.
 *
 * Segment names are never hardcoded. A new line of business is a new row in
 * the sheet, and it appears here without a code change.
 * ------------------------------------------------------------------------- */

const n = (r: Row, k: string) => toNum(r[k]) ?? 0;

/** Sheet months arrive as text or dates. Sorting on a parsed date keeps
 *  "February 2025" ahead of "March 2024" where a string sort would not. */
const monthKey = (r: Row): number => parseDate(r.month)?.getTime() ?? 0;
const monthLabel = (r: Row): string => {
  const d = parseDate(r.month);
  return d ? d.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' }) : String(r.month ?? '');
};

export function CollectionsDashboard({ monthly, segments, drill }: {
  monthly: Row[];
  segments: Row[];
  drill: (title: string, datasetId: string, rows: Row[]) => void;
}) {
  const ordered = useMemo(
    () => [...monthly].sort((a, b) => monthKey(a) - monthKey(b)),
    [monthly]);

  const [picked, setPicked] = useState<string>('');
  const [adding, setAdding] = useState(false);
  const current = useMemo(() => {
    if (!ordered.length) return null;
    const hit = picked ? ordered.find(r => String(r.month) === picked) : undefined;
    return hit ?? ordered[ordered.length - 1];
  }, [ordered, picked]);

  const segRows = useMemo(() => {
    if (!current) return [];
    const key = parseDate(current.month)?.getTime();
    return segments
      .filter(r => parseDate(r.month)?.getTime() === key)
      .sort((a, b) => n(b, 'raised_amount') - n(a, 'raised_amount'));
  }, [segments, current]);

  const trend = useMemo(() => ordered.slice(-12).map(r => ({
    key: String(r.month), label: monthLabel(r), rows: [r],
    values: { raised: n(r, 'raised_amount'), collected: n(r, 'collection_month') },
  })), [ordered]);

  if (!ordered.length || !current) {
    return (
      <div className="card">
        <EmptyState icon="receipt" title="No collections data"
          body="Connect the monthly summary tab and a row per month appears here." />
      </div>
    );
  }

  const raised = n(current, 'raised_amount');
  const collected = n(current, 'collection_month');
  const pending = n(current, 'pending_amount');
  const gap = n(current, 'gap_pct');

  return (
    <>
      {adding && (
        <CollectionsEntryForm
          previousMonth={ordered.length ? ordered[ordered.length - 1] : null}
          onCancel={() => setAdding(false)}
          onDone={() => setAdding(false)} />
      )}

      <section className="section">
        <SectionHeader title="Collections" note={monthLabel(current)} action={
          <span style={{ display: 'flex', gap: 'var(--s2)', alignItems: 'center' }}>
          <Button size="sm" variant="primary" icon="plus" onClick={() => setAdding(true)}>
            New month
          </Button>
          <label className="coll__month">
            <select value={String(current.month)} onChange={e => setPicked(e.target.value)}
              aria-label="Month">
              {[...ordered].reverse().map(r => (
                <option key={String(r.month)} value={String(r.month)}>{monthLabel(r)}</option>
              ))}
            </select>
          </label>
          </span>
        } />

        <div className="grid grid--kpi">
          <div className="metric coll__kpi" data-kpi="1">
            <div className="metric__label">Raised</div>
            <div className="metric__value num">{formatINRCompact(raised)}</div>
            <div className="metric__cmp">Invoiced this month</div>
          </div>
          <div className="metric coll__kpi" data-kpi="2">
            <div className="metric__label">Collected</div>
            <div className="metric__value num">{formatINRCompact(collected)}</div>
            <div className="metric__cmp">Received this month</div>
          </div>
          <div className="metric coll__kpi" data-kpi="3">
            <div className="metric__label">Outstanding</div>
            <div className="metric__value num">{formatINRCompact(pending)}</div>
            <div className="metric__cmp">Pending against this month</div>
          </div>
          <div className="metric coll__kpi" data-kpi="4">
            <div className="metric__label">Gap</div>
            <div className="metric__value num">{formatPct(gap, 1)}</div>
            <div className="metric__cmp">Raised not yet collected</div>
          </div>
        </div>

        {/* Cumulative figures sit apart from the month's four. Mixing "till
            date" into the same row invites reading them as one period. */}
        <div className="coll__strip">
          <div className="coll__cell">
            <span className="coll__lb">Collected to date</span>
            <span className="coll__v num">{formatINRCompact(n(current, 'collection_amount'))}</span>
          </div>
          <div className="coll__cell">
            <span className="coll__lb">Pending to date</span>
            <span className="coll__v num">{formatINRCompact(n(current, 'pending_to_date'))}</span>
          </div>
          <div className="coll__cell">
            <span className="coll__lb">Comparison</span>
            <span className="coll__v num">{n(current, 'comparison').toFixed(2)}</span>
          </div>
        </div>
      </section>

      <section className="section">
        <SectionHeader title="Source of revenue" note={`${segRows.length} segments`} />
        {segRows.length === 0 ? (
          <div className="card">
            <EmptyState icon="receipt" title="No segment rows for this month"
              body="Add a row per segment to the revenue source tab for this month." />
          </div>
        ) : (
          <div className="coll__segs">
            {segRows.map(r => (
              <div key={String(r.segment)} className="coll__seg" role="button" tabIndex={0}
                onClick={() => drill(String(r.segment), 'collections_segments', [r])}>
                <div className="coll__seg-hd">
                  <span className="coll__seg-nm">{String(r.segment)}</span>
                  <span className="coll__seg-share num">{formatPct(n(r, 'share_pct'), 1)}</span>
                </div>
                <div className="coll__seg-bar">
                  <span style={{ width: `${Math.min(100, n(r, 'share_pct'))}%` }} />
                </div>
                <dl className="coll__seg-rows">
                  <div><dt>Raised</dt><dd className="num">{formatINRCompact(n(r, 'raised_amount'))}</dd></div>
                  <div><dt>Collected</dt><dd className="num">{formatINRCompact(n(r, 'collection_amount'))}</dd></div>
                  <div><dt>Gap</dt><dd className="num">{formatINRCompact(n(r, 'gap_amount'))}</dd></div>
                  <div><dt>Gap %</dt><dd className="num">{formatPct(n(r, 'gap_pct'), 2)}</dd></div>
                </dl>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="section">
        <SectionHeader title="Leakage" note={monthLabel(current)} />
        <div className="coll__leak">
          <LeakCell label="Written off" amount={n(current, 'written_off_amount')}
            count={n(current, 'written_off_customers')} />
          <LeakCell label="Discarded" amount={n(current, 'discard_amount')}
            count={n(current, 'discard_customers')} />
          <LeakCell label="3+ invoices pending" amount={n(current, 'aged_amount')}
            count={n(current, 'aged_customers')} tone="warn" />
        </div>
      </section>

      <section className="section">
        <SectionHeader title="Analysis" />
        <div className="grid grid--split">
          <ChartFrame title="Raised against collected" department="collections" height={260}
            question="Is collection keeping up with invoicing?" isEmpty={trend.length < 2}>
            {h => (
              <TrendChart height={h} data={trend} valueFormat={formatINRCompact}
                series={[
                  { id: 'raised', label: 'Raised', kind: 'area', colorIndex: 0 },
                  { id: 'collected', label: 'Collected', kind: 'line', colorIndex: 1 },
                ]}
                onPointClick={p => drill(`Collections — ${p.label}`, 'collections_monthly', p.rows)} />
            )}
          </ChartFrame>

          <ChartFrame title="Gap by segment" department="collections" height={260}
            question="Which line of business is leaking most?" isEmpty={!segRows.length}>
            {h => (
              <CategoryChart height={h} valueFormat={n2 => formatPct(n2, 1)}
                data={segRows.map(r => ({
                  key: String(r.segment), value: n(r, 'gap_pct'), count: 1, rows: [r],
                }))}
                onBarClick={d => drill(d.key, 'collections_segments', d.rows)} />
            )}
          </ChartFrame>
        </div>
      </section>
    </>
  );
}

function LeakCell({ label, amount, count, tone }: {
  label: string; amount: number; count: number; tone?: 'warn';
}) {
  return (
    <div className="coll__leak-cell" data-tone={tone}>
      <span className="coll__lb">{label}</span>
      <span className="coll__leak-v num">{formatINRCompact(amount)}</span>
      <span className="coll__leak-c">{formatInt(count)} customers</span>
    </div>
  );
}
