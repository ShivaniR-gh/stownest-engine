import { useMemo, useState } from 'react';
import '@/styles/collections.css';
import { Button } from '@/components/primitives';
import { createRow } from '@/lib/data/store';
import { parseDate, toNum } from '@/lib/format';
import type { Row } from '@/config/types';

/** ---------------------------------------------------------------------------
 * Monthly collections entry.
 *
 * One form, four rows written: the monthly summary plus one per revenue
 * segment. The generic record form cannot express this because the figures are
 * not independent — most of them are arithmetic over a handful of entered
 * values, exactly as the team's own sheet computes them:
 *
 *   Pending           = Raised − Collected            (Sheet1 C6  = C5-C4)
 *   Gap %             = Pending ÷ Raised × 100        (Sheet1 C7  = C6/C5*100)
 *   Comparison        = (this − prev) ÷ prev          (Sheet1 C10 = (C3-B3)/B3)
 *   Segment gap       = Raised − Collected            (Sheet1 C16 = C14-C15)
 *   Segment gap %     = Gap ÷ Raised × 100            (Sheet1 C17 = C16/C14*100)
 *   Share in revenue  = Collected ÷ month's collected (Sheet1 C18 = C15/C4*100)
 *
 * Storage Rental is NOT entered. The sheet derives it as the remainder after
 * the two transportation segments (C28 = C5-C14-C21, C29 = C4-C15-C22), so
 * asking for it again would let the three segments stop summing to the month.
 * ------------------------------------------------------------------------- */

const n = (v: string | number | undefined) => toNum(v) ?? 0;
const pct = (part: number, whole: number) => (whole > 0 ? (part / whole) * 100 : 0);
const s = (v: number) => String(Number(v.toFixed(2)));

interface Draft {
  month: string;
  collectionTotal: string;   // row 3 — collected against everything outstanding
  collectionMonth: string;   // row 4 — collected against this month
  raised: string;            // row 5
  pendingToDate: string;     // row 9
  pickupRaised: string;
  pickupCollected: string;
  deliveryRaised: string;
  deliveryCollected: string;
}

const EMPTY: Draft = {
  month: '', collectionTotal: '', collectionMonth: '', raised: '', pendingToDate: '',
  pickupRaised: '', pickupCollected: '', deliveryRaised: '', deliveryCollected: '',
};

export function CollectionsEntryForm({ previousMonth, onDone, onCancel }: {
  /** The previous month's row, for the Comparison figure. Null for the first. */
  previousMonth: Row | null;
  onDone: () => void;
  onCancel: () => void;
}) {
  const [d, setD] = useState<Draft>(EMPTY);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const set = (k: keyof Draft) => (e: { target: { value: string } }) =>
    setD(prev => ({ ...prev, [k]: e.target.value }));

  const calc = useMemo(() => {
    const raised = n(d.raised);
    const collectedMonth = n(d.collectionMonth);
    const collectionTotal = n(d.collectionTotal);
    const pending = raised - collectedMonth;

    const pkR = n(d.pickupRaised), pkC = n(d.pickupCollected);
    const dlR = n(d.deliveryRaised), dlC = n(d.deliveryCollected);

    // The remainder, exactly as the sheet computes it.
    const stR = raised - pkR - dlR;
    const stC = collectedMonth - pkC - dlC;

    const prev = previousMonth ? (toNum(previousMonth.collection_amount) ?? 0) : 0;

    const seg = (r: number, c: number) => ({
      raised: r, collected: c, gap: r - c,
      gapPct: pct(r - c, r),
      share: pct(c, collectedMonth),
    });

    return {
      pending,
      gapPct: pct(pending, raised),
      comparison: prev > 0 ? (collectionTotal - prev) / prev : 0,
      pickup: seg(pkR, pkC),
      delivery: seg(dlR, dlC),
      storage: seg(stR, stC),
    };
  }, [d, previousMonth]);

  const problems: string[] = [];
  if (n(d.collectionMonth) > n(d.raised)) problems.push('Collected this month cannot exceed the amount raised.');
  if (calc.storage.raised < 0) problems.push('Pickup and delivery raised together exceed the month\u2019s raised total.');
  if (calc.storage.collected < 0) problems.push('Pickup and delivery collected together exceed the month\u2019s collected total.');

  const submit = async () => {
    setError(null);
    if (!d.month) { setError('Pick a month.'); return; }
    if (problems.length) { setError(problems[0]); return; }
    setBusy(true);
    try {
      await createRow('collections_monthly', {
        month: d.month,
        collection_amount: d.collectionTotal,
        collection_month: d.collectionMonth,
        raised_amount: d.raised,
        pending_amount: s(calc.pending),
        gap_pct: s(calc.gapPct),
        pending_to_date: d.pendingToDate,
        comparison: s(calc.comparison),
      });

      // Sequential, not parallel: the sheet append is last-write-wins on a row
      // index, so three concurrent writes can land on top of each other.
      const segs: [string, typeof calc.pickup][] = [
        ['Transportation (Pickup)', calc.pickup],
        ['Transportation (Delivery)', calc.delivery],
        ['Storage Rental', calc.storage],
      ];
      for (const [name, v] of segs) {
        await createRow('collections_segments', {
          month: d.month, segment: name,
          raised_amount: s(v.raised), collection_amount: s(v.collected),
          gap_amount: s(v.gap), gap_pct: s(v.gapPct), share_pct: s(v.share),
        });
      }
      onDone();
    } catch (e) {
      setError((e as Error).message || 'Could not save. Nothing was written.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="modal__scrim" onClick={e => e.target === e.currentTarget && onCancel()}>
      <div className="modal modal--wide" role="dialog" aria-modal="true" aria-label="Monthly collections">
        <header className="modal__hd">
          <h2 className="modal__title">Monthly collections</h2>
        </header>

        <div className="modal__bd">
          {error && <div className="cef__err" role="alert">{error}</div>}

          <div className="formrow" style={{ maxWidth: 220, marginBottom: 'var(--s5)' }}>
            <label className="formrow__lb" htmlFor="cef-month">Month</label>
            <input id="cef-month" className="field" type="date" value={d.month} onChange={set('month')} />
            <span className="formrow__hint">First of the month.</span>
          </div>

          <h3 className="cef__sec">Collection</h3>
          <div className="cef__grid">
            <Field label="Collection Amount" value={d.collectionTotal} onChange={set('collectionTotal')}
              hint="Collected against everything outstanding." />
            <Field label="Collection amount for the month" value={d.collectionMonth} onChange={set('collectionMonth')} />
            <Field label="Raised Invoice amount" value={d.raised} onChange={set('raised')} />
            <Field label="Total Pending Invoice amount till date" value={d.pendingToDate} onChange={set('pendingToDate')} />
          </div>

          <h3 className="cef__sec">Source of revenue</h3>

          <h4 className="cef__sub">Transportation (Pickup)</h4>
          <div className="cef__grid">
            <Field label="Raised Invoices Amount of pickup" value={d.pickupRaised} onChange={set('pickupRaised')} />
            <Field label="Collection Amount of pickup" value={d.pickupCollected} onChange={set('pickupCollected')} />
          </div>

          <h4 className="cef__sub">Transportation (Delivery)</h4>
          <div className="cef__grid">
            <Field label="Raised Invoices Amount of delivery" value={d.deliveryRaised} onChange={set('deliveryRaised')} />
            <Field label="Collection Amount of delivery" value={d.deliveryCollected} onChange={set('deliveryCollected')} />
          </div>

          {/* Storage Rental has no inputs at all — the sheet derives it as the
              remainder after pickup and delivery, so there is nothing to type. */}
          <p className="cef__note">
            Storage Rental is calculated as the month total less pickup and delivery.
            It appears in the records once saved.
          </p>


          {problems.length > 0 && (
            <ul className="cef__warn">{problems.map(p => <li key={p}>{p}</li>)}</ul>
          )}
        </div>

        <footer className="modal__ft">
          <Button onClick={onCancel} disabled={busy}>Cancel</Button>
          <Button variant="primary" onClick={submit} disabled={busy || problems.length > 0}>
            {busy ? 'Saving\u2026' : 'Save month'}
          </Button>
        </footer>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, hint }: {
  label: string; value: string; hint?: string;
  onChange: (e: { target: { value: string } }) => void;
}) {
  return (
    <div className="formrow">
      <label className="formrow__lb">{label}</label>
      <span className="cef__money">
        <span className="cef__cur" aria-hidden="true">₹</span>
        <input className="field num" inputMode="decimal" value={value}
          onChange={onChange} placeholder="0" />
      </span>
      {hint && <span className="formrow__hint">{hint}</span>}
    </div>
  );
}


export const monthOf = (r: Row) => parseDate(r.month)?.getTime() ?? 0;
