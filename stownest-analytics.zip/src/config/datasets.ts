import type { DatasetDef } from './types';

/** ---------------------------------------------------------------------------
 * SHEET MAPPING.
 * `sheetColumn` is the exact header text in the Google Sheet tab. This file is
 * the ONLY place that knows about sheet headers — rename a header in Sheets and
 * you change one line here.
 *
 * A column with no `sheetColumn` is treated as unmapped: it is hidden from
 * tables and every metric that requires it renders "Data unavailable" naming
 * the missing column. Nothing is ever estimated to fill a gap.
 * ------------------------------------------------------------------------- */

/** ---------------------------------------------------------------------------
 * DATASET SCHEMA — the application's definition of its own data.
 *
 * This file is the source of truth. It decides what the entry form shows, what
 * the API accepts, what header row a newly created tab gets, and which sheet
 * column each value lands in. One list, four uses, so they cannot drift apart.
 *
 * The spreadsheet is the storage destination, never the definition. Nothing
 * here is inferred from what a sheet happens to contain.
 * ------------------------------------------------------------------------- */

export const DATASETS: DatasetDef[] = [

  /* ------------------------------------------------------------------ *
   * Warehouses — the master list.
   *
   * One row per warehouse, no months. This is what fills the dropdown on the
   * readings form, and the only place total space is edited. Employees hold
   * VIEW here but not UPDATE, so they can select a warehouse without being
   * able to change its size.
   * ------------------------------------------------------------------ */
  {
    id: 'warehouses',
    label: 'Warehouses',
    noun: 'warehouse',
    department: 'facility',
    spreadsheetEnv: 'SHEETS_ID_FACILITY',
    sheetName: 'Warehouses',
    createMissingTab: true,
    idColumn: 'wh_code',
    titleColumn: 'wh_name',
    subtitleColumns: ['city', 'location'],
    statusColumn: 'status',
    defaultSort: { key: 'wh_code', dir: 'asc' },
    auditable: true,
    columns: [
      { key: 'wh_code', header: 'WH Code', type: 'id', sheetColumn: 'WH Code',
        required: true, editable: true, unique: true, filterable: true, sortable: true,
        pattern: '^[A-Za-z0-9:_-]{3,32}$', patternHint: 'PUN:002',
        help: 'Unique code for this warehouse. Used by every monthly reading.' },

      { key: 'wh_name', header: 'WH Name', type: 'text', sheetColumn: 'WH Name',
        required: true, editable: true, sortable: true },

      { key: 'city', header: 'City', type: 'enum', sheetColumn: 'City',
        required: true, editable: true, filterable: true, groupable: true,
        enumValues: ['Bangalore', 'Chennai', 'Delhi', 'Hyderabad', 'Mumbai', 'Pune'], role: 'location' },

      { key: 'location', header: 'Location', type: 'text', sheetColumn: 'Location',
        editable: true, filterable: true, groupable: true,
        help: 'Area within the city, e.g. Alur or Rampura.' },

      { key: 'total_space', header: 'Total Space (sqft)', type: 'number', sheetColumn: 'Total Space',
        required: true, editable: true, min: 1, aggregate: 'sum', role: 'capacity',
        help: 'Changing this affects future readings only. Past months keep the figure recorded at the time.' },

      { key: 'status', header: 'Status', type: 'enum', sheetColumn: 'Status',
        required: true, editable: true, filterable: true,
        enumValues: ['Active', 'Inactive'], role: 'status',
        tone: { Active: 'pos', Inactive: 'idle' },
        help: 'Inactive warehouses stay in past readings but leave the dropdown.' },
    ],
  },

  /* ------------------------------------------------------------------ *
   * Warehouse space readings — one tab per month.
   *
   * The employee supplies two values: which warehouse, and how much of it is
   * occupied this month. Everything else is filled by the server.
   *
   * wh_name / city / location / total_space are SNAPSHOT from the master at
   * write time rather than joined at read time. If a warehouse is expanded in
   * June, March must keep showing March's figures — a live join would rewrite
   * history and reshape every trend chart behind it.
   * ------------------------------------------------------------------ */
  {
    id: 'warehouse_readings',
    label: 'Warehouse Space',
    noun: 'reading',
    department: 'facility',
    spreadsheetEnv: 'SHEETS_ID_FACILITY',
    sheetName: 'Readings',
    tabStrategy: 'monthly',
    tabPrefix: 'Readings',
    monthsBack: 24,
    monthsForward: 1,
    createMissingTab: true,
    idColumn: 'wh_code',
    titleColumn: 'wh_name',
    subtitleColumns: ['city'],
    dateColumn: 'recorded_on',
    defaultSort: { key: 'city', dir: 'asc' },
    auditable: true,
    columns: [
      // --- entered by the user ---
      { key: 'wh_code', header: 'WH Code', type: 'id', sheetColumn: 'WH Code',
        required: true, editable: true, unique: true, filterable: true, sortable: true,
        help: 'Chosen from the warehouse list. One reading per warehouse per month.' },

      { key: 'occupied_space', header: 'Occupied Space (sqft)', type: 'number', sheetColumn: 'Occupied Space',
        required: true, editable: true, min: 0, aggregate: 'sum', role: 'occupied',
        help: 'Space in use this month. Cannot exceed the warehouse total.' },

      { key: 'recorded_on', header: 'Recorded On', type: 'date', sheetColumn: 'Recorded On',
        editable: true, role: 'date',
        help: 'Defaults to today if left blank.' },

      // --- filled by the server (api/_lib/derive.ts) ---
      // Written into the row as well as computed, so the tab reads properly
      // when someone opens the spreadsheet directly.
      { key: 'wh_name', header: 'WH Name', type: 'text', sheetColumn: 'WH Name',
        derived: true, sortable: true },

      { key: 'city', header: 'City', type: 'enum', sheetColumn: 'City',
        derived: true, filterable: true, groupable: true,
        enumValues: ['Bangalore', 'Chennai', 'Delhi', 'Hyderabad', 'Mumbai', 'Pune'], role: 'location' },

      { key: 'location', header: 'Location', type: 'text', sheetColumn: 'Location',
        derived: true, filterable: true, groupable: true },

      { key: 'total_space', header: 'Total Space (sqft)', type: 'number', sheetColumn: 'Total Space',
        derived: true, aggregate: 'sum', role: 'capacity',
        help: 'Snapshot of the warehouse total at the time this reading was entered.' },

      { key: 'available_space', header: 'Available Space (sqft)', type: 'number', sheetColumn: 'Available Space',
        derived: true, aggregate: 'sum',
        help: 'Total minus occupied. Computed, never entered.' },

      { key: 'utilisation_pct', header: 'Utilisation %', type: 'percent', sheetColumn: 'Utilisation %',
        derived: true },

      { key: 'entered_by', header: 'Entered By', type: 'email', sheetColumn: 'Entered By',
        derived: true,
        help: 'Every write is by the service account, so this is the only record of who submitted it.' },
    ],
    crossFieldRules: [
      (v) => {
        const occ = Number(String(v.occupied_space ?? '').replace(/[,\s]/g, ''));
        return occ < 0 ? { key: 'occupied_space', message: 'Occupied space cannot be negative.' } : null;
      },
    ],
  },

  /* ------------------------------------------------------------------ *
   * Collections — monthly summary.
   *
   * One row per month. The team's working sheet is transposed (months across
   * columns, metrics down rows), which the platform cannot read: row 1 must be
   * headers and every later row a record. Point sheetName at a helper tab that
   * TRANSPOSE()s the working grid, so the team keeps editing the layout they
   * already use and the app reads a shape it understands.
   * ------------------------------------------------------------------ */
  {
    id: 'collections_monthly',
    label: 'Collection',
    noun: 'month',
    department: 'collections',
    spreadsheetEnv: 'SHEETS_ID_COLLECTIONS',
    sheetName: 'monthly_summary',
    idColumn: 'month',
    titleColumn: 'month',
    dateColumn: 'month',
    defaultSort: { key: 'month', dir: 'desc' },
    auditable: true,
    columns: [
      { key: 'month', header: 'Month', type: 'date', sheetColumn: 'Month',
        required: true, filterable: true, sortable: true, role: 'date',
        help: 'First of the month. One row per month.' },

      { key: 'collection_amount', header: 'Collection Amount', type: 'currency',
        sheetColumn: 'Collection Amount', aggregate: 'sum', editable: true, min: 0,
        help: 'Total collected against all outstanding, not only this month.' },

      { key: 'collection_month', header: 'Collection (this month)', type: 'currency',
        sheetColumn: 'Collection amount for the month', aggregate: 'sum', editable: true, min: 0,
        help: 'Received against this month only, not the running total.' },

      { key: 'raised_amount', header: 'Raised Invoice Amount', type: 'currency',
        sheetColumn: 'Raised Invoice amount', aggregate: 'sum', role: 'amount',
        editable: true, min: 0 },

      { key: 'pending_amount', header: 'Pending Collection', type: 'currency',
        sheetColumn: 'Pending collection amount', aggregate: 'sum', derived: true,
        help: 'Raised minus collected. Computed, never entered.' },

      { key: 'gap_pct', header: 'Gap %', type: 'percent', sheetColumn: 'Gap in %',
        derived: true, help: 'Share of raised invoicing not yet collected. Computed.' },

      { key: 'pending_to_date', header: 'Pending To Date', type: 'currency',
        sheetColumn: 'Total Pending Invoice amount till date', editable: true, min: 0,
        help: 'Cumulative, not this month alone.' },

      { key: 'comparison', header: 'Comparison', type: 'number', sheetColumn: 'Comparison',
        editable: true,
        help: 'Month-on-month movement as a ratio, as recorded by the team.' },

      { key: 'written_off_amount', header: 'Written Off', type: 'currency',
        sheetColumn: 'Written off amount', editable: true, min: 0 },
      { key: 'written_off_customers', header: 'Written Off Customers', type: 'number',
        sheetColumn: 'Written off customer', editable: true, min: 0 },
      { key: 'discard_amount', header: 'Discard Amount', type: 'currency',
        sheetColumn: 'Discard amount', editable: true, min: 0 },
      { key: 'discard_customers', header: 'Discard Customers', type: 'number',
        sheetColumn: 'Discard customers', editable: true, min: 0 },
      { key: 'aged_amount', header: '3+ Invoices Pending', type: 'currency',
        sheetColumn: '3 and More than 3 invoice amount pending', editable: true, min: 0 },
      { key: 'aged_customers', header: '3+ Invoices Customers', type: 'number',
        sheetColumn: '3 and More than 3 invoice amount pending Customers',
        editable: true, min: 0 },
    ],
  },

  /* ------------------------------------------------------------------ *
   * Collections — revenue source split.
   *
   * One row per month PER segment rather than one column per segment, so a
   * new line of business is a new row the team types, not a schema change.
   * ------------------------------------------------------------------ */
  {
    id: 'collections_segments',
    label: 'Revenue source',
    noun: 'segment reading',
    department: 'collections',
    spreadsheetEnv: 'SHEETS_ID_COLLECTIONS',
    sheetName: 'revenue_source',
    idColumn: 'segment',
    titleColumn: 'segment',
    dateColumn: 'month',
    subTabColumn: 'segment',
    defaultSort: { key: 'month', dir: 'desc' },
    auditable: true,
    columns: [
      { key: 'month', header: 'Month', type: 'date', sheetColumn: 'Month',
        required: true, editable: true, filterable: true, sortable: true, role: 'date',
        help: 'First of the month. One row per segment per month.' },

      // An enum, not free text: three fixed lines of business, and a typo
      // would split one segment into two on every chart.
      { key: 'segment', header: 'Segment', type: 'enum', sheetColumn: 'Segment',
        required: true, editable: true, filterable: true, groupable: true, sortable: true,
        role: 'name',
        enumValues: ['Transportation (Pickup)', 'Transportation (Delivery)', 'Storage Rental'] },

      { key: 'raised_amount', header: 'Raised Invoices Amount', type: 'currency',
        sheetColumn: 'Raised Invoices Amount', aggregate: 'sum', role: 'amount',
        editable: true, min: 0 },
      { key: 'collection_amount', header: 'Collection Amount', type: 'currency',
        sheetColumn: 'Collection Amount', aggregate: 'sum', editable: true, min: 0 },
      { key: 'gap_amount', header: 'Gap in Rs.', type: 'currency',
        sheetColumn: 'Gap in Rs.', aggregate: 'sum', derived: true,
        help: 'Raised minus collected. Computed, never entered.' },
      { key: 'gap_pct', header: 'Gap %', type: 'percent', sheetColumn: 'Gap in %',
        derived: true, help: 'Computed from the two figures above.' },
      { key: 'share_pct', header: 'Share in Revenue', type: 'percent',
        sheetColumn: 'Share in revenue', editable: true, min: 0,
        help: 'This segment as a share of all revenue that month.' },
    ],
    crossFieldRules: [
      // Collected above raised is a typo every time, and it silently produces a
      // negative gap that reads as a surplus on the dashboard.
      (v) => {
        const num = (x: unknown) => Number(String(x ?? '').replace(/[,\s]/g, ''));
        return num(v.collection_amount) > num(v.raised_amount)
          ? { key: 'collection_amount', message: 'Collected cannot exceed raised.' }
          : null;
      },
    ],
  },

  {
    id: 'access_control',
    label: 'Users & access',
    noun: 'user',
    department: 'administration',
    sheetName: 'access_control',
    idColumn: 'email',
    statusColumn: 'status',
    titleColumn: 'name',
    subtitleColumns: ['email', 'role'],
    auditable: true,
    columns: [
      { key: 'email', header: 'Email', type: 'email', sheetColumn: 'Email', width: 230, sortable: true, required: true },
      { key: 'name', header: 'Name', type: 'text', sheetColumn: 'Name', width: 170, sortable: true, editable: true, required: true },
      {
        key: 'role', header: 'Role', type: 'enum', sheetColumn: 'Role', width: 160,
        enumValues: ['super_admin', 'department_admin', 'employee'],
        tone: { super_admin: 'accent', department_admin: 'idle', employee: 'idle' },
        filterable: true, groupable: true, sortable: true, editable: true, required: true,
      },
      { key: 'departments', header: 'Departments', type: 'text', sheetColumn: 'Departments', width: 240, editable: true,
        help: 'Comma-separated department ids. Ignored for super_admin.' },
      { key: 'grants', header: 'Extra grants', type: 'text', sheetColumn: 'Grants', width: 180, editable: true,
        help: 'Comma-separated actions granted beyond the role default, e.g. DELETE,EXPORT.' },
      {
        key: 'status', header: 'Status', type: 'enum', sheetColumn: 'Status', width: 110,
        enumValues: ['Active', 'Suspended'], tone: { Active: 'pos', Suspended: 'neg' },
        filterable: true, sortable: true, editable: true, required: true,
      },
    ],
  },
];

/** ---------------------------------------------------------------------------
 * Runtime registry.
 *
 * DATASETS above is the SEED: defaults compiled into the bundle. At sign-in the
 * app fetches the live registry (assembled from the data_sources and
 * field_mappings tabs) and calls hydrate(), which swaps these in place.
 *
 * getDataset() deliberately stays SYNCHRONOUS. Every page, table, form and chart
 * already reads schema through it, so hydrating a module-level map means the
 * whole UI becomes configuration-driven without a single one of them changing.
 * ------------------------------------------------------------------------- */

let registry: DatasetDef[] = DATASETS;
let byId: Record<string, DatasetDef> = Object.fromEntries(DATASETS.map(d => [d.id, d]));
const listeners = new Set<() => void>();

export function hydrateDatasets(defs: DatasetDef[]): void {
  if (!defs.length) return;
  registry = defs;
  byId = Object.fromEntries(defs.map(d => [d.id, d]));
  listeners.forEach(fn => fn());
}

export const onRegistryChange = (fn: () => void) => { listeners.add(fn); return () => listeners.delete(fn); };

export const allDatasets = (): DatasetDef[] => registry;
/**
 * Schema for a dataset id.
 *
 * Accepts a month-scoped id ("warehouse_readings::Readings SEP 2026") as well
 * as a plain one. A month is a different set of ROWS, not a different schema,
 * so both resolve to the same definition.
 */
export const getDataset = (id: string): DatasetDef | undefined =>
  byId[id.includes('::') ? id.slice(0, id.indexOf('::')) : id];
export const isMapped = (datasetId: string, columnKey: string) =>
  Boolean(byId[datasetId]?.columns.find(c => c.key === columnKey)?.sheetColumn);
export const visibleColumns = (d: DatasetDef) => d.columns.filter(c => c.sheetColumn);

/** @deprecated reads the seed only; use getDataset() or allDatasets(). */
export const DATASET_BY_ID = byId;
