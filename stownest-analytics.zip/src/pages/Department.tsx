import { useMemo, useState } from 'react';
import { Navigate, useParams } from 'react-router-dom';
import type { DepartmentId } from '@/config/types';
import { DEPT_BY_ID } from '@/config/departments';
import { allDatasets, getDataset } from '@/config/datasets';
import { TopBar } from '@/components/shell/TopBar';
import { ControlBar } from '@/components/filters/ControlBar';
import {
  DatasetFilters, EMPTY_FILTERS, applyViewFilters, type ViewFilters,
} from '@/components/filters/DatasetFilters';
import { MetricGrid, SectionHeader } from '@/components/metrics/MetricCard';
import { DatasetPanel } from '@/components/data/DatasetPanel';
import { DrillDown } from '@/components/data/DrillDown';
import { DepartmentCharts } from './DepartmentCharts';
import { CapacityDashboard } from '@/components/metrics/CapacityDashboard';
import { CollectionsEntryForm } from '@/components/metrics/CollectionsEntryForm';
import { deriveKpis, deriveSchema } from '@/lib/analytics/deriveSchema';
import { Button, ErrorState } from '@/components/primitives';
import { useMetrics } from '@/lib/analytics/useMetrics';
import { useDatasets } from '@/lib/data/useDataset';
import { useAnalytics } from '@/lib/analytics/AnalyticsContext';
import { useDrill } from '@/lib/analytics/useDrill';
import { applyFilters, applyPeriod } from '@/lib/analytics/filters';
import { scopedId } from '@/lib/data/store';
import { parseDate } from '@/lib/format';
import { usePermission } from '@/lib/permissions/usePermission';

type View = 'dashboard' | 'records';

/**
 * One page serves every department.
 *
 * Dashboard and Records are separate views over the same datasets, each with
 * its own filter state — including its own month. Filtering the charts to one
 * city does not silently change what the records table shows, which matters
 * because the two get used for different jobs: a monthly review versus finding
 * one warehouse.
 */
export default function Department() {
  const { deptId } = useParams<{ deptId: string }>();
  const dept = DEPT_BY_ID[deptId as DepartmentId];
  const { hasDepartment } = usePermission();
  const { period, compare, filters } = useAnalytics();
  const drill = useDrill();

  const [view, setView] = useState<View>('dashboard');

  /**
   * Which dataset is in view. Defaults to the first one that carries a
   * capacity/occupied pair, because that is the one with a dashboard worth
   * showing — landing on a flat master list gives an empty Analysis section
   * and no indication that another dataset exists.
   */
  const [tab, setTab] = useState<number | null>(null);
  const [dashFilters, setDashFilters] = useState<ViewFilters>(EMPTY_FILTERS);
  const [recFilters, setRecFilters] = useState<ViewFilters>(EMPTY_FILTERS);
  /** Which sub-tab of the records table is open, for datasets that declare one. */
  const [subTab, setSubTab] = useState<string>('');
  /** Departments with a combined entry form open it from the view header,
   *  so one button serves both Dashboard and Records. */
  const [entering, setEntering] = useState(false);

  const datasetIds = useMemo(() => {
    if (!dept) return [];
    return allDatasets().filter(d => d.department === dept.id).map(d => d.id);
  }, [dept]);

  const { metrics, error, fetchedAt, status, refresh } = useMetrics(dept?.metrics ?? []);

  const defaultTab = useMemo(() => {
    const i = datasetIds.findIndex(id => {
      const d = getDataset(id);
      return d?.columns.some(c => c.role === 'capacity')
          && d?.columns.some(c => c.role === 'occupied');
    });
    return i >= 0 ? i : 0;
  }, [datasetIds]);

  const activeTab = tab ?? defaultTab;
  const activeDataset = getDataset(datasetIds[activeTab] ?? '');
  const monthly = activeDataset?.tabStrategy === 'monthly';

  // Each view reads its own month, so both are fetched and cached separately.
  const dashId = activeDataset
    ? (monthly && dashFilters.month ? scopedId(activeDataset.id, dashFilters.month) : activeDataset.id)
    : '';
  // Falls back to the dashboard's month for the first render, before the
  // records bar has fetched its month list — otherwise the panel briefly
  // loads the unscoped dataset id.
  const recMonth = recFilters.month || dashFilters.month;
  const recId = activeDataset
    ? (monthly && recMonth ? scopedId(activeDataset.id, recMonth) : activeDataset.id)
    : '';

  const loadIds = useMemo(
    () => [...new Set([...datasetIds, dashId, recId].filter(Boolean))],
    [datasetIds, dashId, recId]);
  const { byId } = useDatasets(loadIds);

  const scoped = useMemo(() => {
    const out: Record<string, ReturnType<typeof applyFilters>> = {};
    for (const id of loadIds) {
      const ds = getDataset(id);
      out[id] = ds ? applyFilters(applyPeriod(byId[id] ?? [], ds, period), filters, ds) : [];
    }
    return out;
  }, [byId, loadIds, period, filters]);

  // Unfiltered rows feed the filter dropdowns; filtered rows feed the view.
  const dashAll = activeDataset ? scoped[dashId] ?? [] : [];
  const dashRows = useMemo(() => applyViewFilters(dashAll, dashFilters), [dashAll, dashFilters]);

  // Every hook must run before these — bailing out above useMemo changes the
  // hook count between renders and React throws on the way to /forbidden.
  if (!dept) return <Navigate to="/404" replace />;
  if (!hasDepartment(dept.id)) return <Navigate to="/forbidden" replace />;

  const busy = status === 'loading' || status === 'refreshing';

  // Values come from the column's enum, not from the rows in view. A segment
  // with no readings yet still needs a tab, or it can never be added.
  const subTabCol = activeDataset?.subTabColumn
    ? activeDataset.columns.find(c => c.key === activeDataset.subTabColumn)
    : undefined;
  const subTabs = subTabCol?.enumValues ?? [];

  // Newest existing month, for the Comparison figure inside the form.
  const priorMonth = useMemo(() => {
    const rows = scoped['collections_monthly'] ?? [];
    return rows.length
      ? [...rows].sort((a, b) => (parseDate(b.month)?.getTime() ?? 0)
                               - (parseDate(a.month)?.getTime() ?? 0))[0]
      : null;
  }, [scoped]);
  const activeSubTab = subTabs.includes(subTab) ? subTab : (subTabs[0] ?? '');

  const schema = activeDataset ? deriveSchema(activeDataset, dashRows) : null;
  const derivedKpis = activeDataset && schema
    ? deriveKpis(activeDataset, dashRows, [], schema, 6) : [];

  const datasetSwitcher = datasetIds.length > 1 ? (
    <span style={{ display: 'flex', gap: 4 }}>
      {datasetIds.map((id, i) => (
        <Button key={id} size="sm" variant={i === activeTab ? 'default' : 'ghost'}
          aria-pressed={i === activeTab} onClick={() => setTab(i)}>
          {getDataset(id)?.label ?? id}
        </Button>
      ))}
    </span>
  ) : undefined;

  return (
    <>
      <TopBar title={dept.label} crumb={[{ label: 'Workspace', to: '/' }]} />
      <ControlBar datasetIds={datasetIds} fetchedAt={fetchedAt} busy={busy} onRefresh={refresh} />

      <div className="page">
        <div className="view-head">
          {datasetSwitcher}
          <div className="view-head__row">
          <div className="view-toggle" role="tablist" aria-label="View">
            <button role="tab" aria-selected={view === 'dashboard'}
              className={`view-toggle__btn${view === 'dashboard' ? ' is-active' : ''}`}
              onClick={() => setView('dashboard')}>Dashboard</button>
            <button role="tab" aria-selected={view === 'records'}
              className={`view-toggle__btn${view === 'records' ? ' is-active' : ''}`}
              onClick={() => setView('records')}>Records</button>
          </div>

          {dept.customDashboard && (
            <Button size="sm" variant="primary" icon="plus"
              onClick={() => setEntering(true)}>New record</Button>
          )}
          </div>
        </div>

        {entering && (
          <CollectionsEntryForm previousMonth={priorMonth}
            onCancel={() => setEntering(false)}
            onDone={() => { setEntering(false); refresh(); }} />
        )}


        {status === 'error' && !Object.values(byId).some(r => r.length) ? (
          <ErrorState title={`Could not load ${dept.label} data`}
            body={error?.message ?? 'The data service did not respond.'} onRetry={refresh} />
        ) : view === 'dashboard' ? (
          <>
            {activeDataset && !dept.customDashboard && (
              <DatasetFilters dataset={activeDataset} rows={dashAll}
                value={dashFilters} onChange={setDashFilters} />
            )}

            {/* CapacityDashboard renders its own KPI row, so the separate
                "Key figures" section is only shown for datasets it cannot
                handle — otherwise the same five cards appeared twice. */}
            {activeDataset && schema?.hasUtilisation ? (
              <CapacityDashboard ds={activeDataset} rows={dashRows} schema={schema} />
            ) : (
              <>
                {/* A department with its own dashboard already shows its
                    figures; deriveKpis would guess a second set from the same
                    columns and print every number twice. */}
                {!dept.customDashboard && (metrics.length > 0 || derivedKpis.length > 0) && (
                  <section className="section">
                    <SectionHeader title="Key figures" note={period.label} />
                    <MetricGrid metrics={[...metrics, ...derivedKpis]} compare={compare}
                      onDrill={drill.openMetric} />
                  </section>
                )}
                <section className="section">
                  <SectionHeader title="Analysis" />
                  <DepartmentCharts department={dept.id}
                    ctx={{ rows: scoped, period, drill: (t, d, r) => drill.openRows(t, d, r) }} />
                </section>
              </>
            )}
          </>
        ) : (
          activeDataset && (
            <section className="section">
              <SectionHeader title="Records" />

              {subTabs.length > 1 && (
                <div className="subtabs" role="tablist" aria-label={subTabCol?.header ?? 'View'}>
                  {subTabs.map(v => (
                    <button key={v} role="tab" aria-selected={v === activeSubTab}
                      className={`subtabs__btn${v === activeSubTab ? ' is-active' : ''}`}
                      onClick={() => setSubTab(v)}>{v}</button>
                  ))}
                </div>
              )}

              {monthly && (
                <DatasetFilters dataset={activeDataset} rows={scoped[recId] ?? []}
                  value={recFilters} onChange={setRecFilters} />
              )}
              <DatasetPanel
                key={`${activeDataset.id}:${recMonth}:${activeSubTab}`}
                dataset={activeDataset}
                allowCreate={!dept.customDashboard}
                month={monthly ? String(recMonth) : undefined}
                prefilter={r =>
                  applyViewFilters([r], recFilters).length > 0
                  && (!activeSubTab || !subTabCol
                      || String(r[subTabCol.key] ?? '').trim() === activeSubTab)}
              />
            </section>
          )
        )}
      </div>

      {drill.target && getDataset(drill.target.datasetId) && (
        <DrillDown title={drill.target.title} subtitle={drill.target.subtitle}
          dataset={getDataset(drill.target.datasetId)!} rows={drill.target.rows} onClose={drill.close} />
      )}
    </>
  );
}
